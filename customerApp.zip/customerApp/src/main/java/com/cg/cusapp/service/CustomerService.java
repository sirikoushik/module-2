package com.cg.cusapp.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cg.cusapp.bean.Customer;
import com.cg.cusapp.exception.CustomerException;

public interface CustomerService {
public List<Customer> addCustomer(Customer cust)throws CustomerException;
public Customer getCustomerById(int id) throws CustomerException;
public ResponseEntity<String> deleteCustomer(int id) throws CustomerException;
public List<Customer> getAllCustomers() throws CustomerException;
public List<Customer> updateCustomer(int id,Customer cust) throws CustomerException;
public List<Customer> getCustomerByCity(String city) throws CustomerException;
}
