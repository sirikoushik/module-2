package com.cg.cusapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//@EntityScan("com.cg.cusapp")
//@ComponentScan("com.cg.cusapp")
//@EnableJpaRepositories
@SpringBootApplication
public class CustomerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerAppApplication.class, args);
	}

}
