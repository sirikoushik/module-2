package com.cg.cusapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.cusapp.bean.Customer;
import com.cg.cusapp.exception.CustomerException;
import com.cg.cusapp.service.CustomerService;



@RestController
public class CustomerController {
	@Autowired
	CustomerService customerService;
@RequestMapping("/customer")
public List<Customer> getCustomers() throws CustomerException{
	return customerService.getAllCustomers();
}
@RequestMapping(value="/customer",method=RequestMethod.POST)
public List<Customer> addCustomer(@RequestBody Customer cust) throws CustomerException{
return customerService.addCustomer(cust);
}
@RequestMapping("/customer/{id}")
public Customer getCustomerById(@PathVariable int id) throws CustomerException{
	return customerService.getCustomerById(id);
}
@RequestMapping("/getCustomerByCity/{city}")
public List<Customer> findCustomerByCity(@PathVariable String city) throws CustomerException{
	return customerService.getCustomerByCity(city);
}
@DeleteMapping("/customer/{id}")
public ResponseEntity<String> deleteCustomer(@PathVariable int id) throws CustomerException{
	customerService.deleteCustomer(id);
	return new ResponseEntity<String>("Customer with id "+id+" deleted",HttpStatus.OK);
}
@PutMapping("/customer/{id}")
public List<Customer> updateCustomer(@PathVariable int id,@RequestBody Customer cust) throws CustomerException{
	return customerService.updateCustomer(id, cust);
}
//@ExceptionHandler({CustomerException.class})
//public ResponseEntity<String> handleErrors(Exception e){
//	return new ResponseEntity<String>("An Error occured"+e.getMessage(),HttpStatus.CONFLICT);
//	// TODO Auto-generated constructor stub
//}
}
