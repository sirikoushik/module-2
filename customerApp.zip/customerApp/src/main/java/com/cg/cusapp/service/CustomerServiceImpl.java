package com.cg.cusapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.cusapp.bean.Customer;
import com.cg.cusapp.dao.CustomerDao;
import com.cg.cusapp.exception.CustomerException;
@Service
public class CustomerServiceImpl implements CustomerService{
	@Autowired
	CustomerDao customerDao;
	@Override
	public List<Customer> addCustomer(Customer cust) throws CustomerException {
		// TODO Auto-generated method stub
		try {
		customerDao.save(cust);
		return customerDao.findAll();
		}catch(Exception e) {
			throw new CustomerException(e.getMessage());
		}
		}

	@Override
	public Customer getCustomerById(int id) throws CustomerException {
		// TODO Auto-generated method stub
		try {
		return customerDao.findById(id).get();
		}catch(Exception e) {
			throw new CustomerException(e.getMessage());
		}
	}

	@Override
	public ResponseEntity<String> deleteCustomer(int id) throws CustomerException {
		// TODO Auto-generated method stub
		try{
			customerDao.deleteById(id);
		}catch(Exception e) {
			throw new CustomerException(e.getMessage());
		}
		return null;
		}

	@Override
	public List<Customer> getAllCustomers() throws CustomerException {
		// TODO Auto-generated method stub
		try {
			return customerDao.findAll();
		} catch (Exception e) {
			throw new CustomerException(e.getMessage());
			// TODO: handle exception
		}
	}

	@Override
	public List<Customer> updateCustomer(int id, Customer cust) throws CustomerException {
		// TODO Auto-generated method stub
		try {
			Optional<Customer> optional=customerDao.findById(id);
			if(optional.isPresent()) {
				Customer customer=optional.get();
				customer.setType(cust.getType());
				customer.setCity(cust.getCity());
				customerDao.save(customer);
				return getAllCustomers();
			}
			else {
				throw new CustomerException("Customer with Id"+id+"does not exist");
			}
		} catch (Exception e) {
			// TODO: handle exception
			throw new CustomerException(".....");
		}
		
	}

	@Override
	public List<Customer> getCustomerByCity(String city) throws CustomerException {
		// TODO Auto-generated method stub
		try {
		return customerDao.getCustomerByCity(city);
		}catch(Exception e) {
			throw new CustomerException(e.getMessage());
		}
	}

}
