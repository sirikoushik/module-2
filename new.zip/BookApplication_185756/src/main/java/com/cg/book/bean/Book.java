package com.cg.book.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
public class Book
{
	@Id
	@GeneratedValue
	private int bookId;
	@NotBlank
	private String bookName;
	@NotBlank
	private double bookPrice;
	@NotBlank
	private String authoer;
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public double getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}
	public String getAuthoer() {
		return authoer;
	}
	public void setAuthoer(String authoer) {
		this.authoer = authoer;
	}
	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", bookPrice=" + bookPrice + ", authoer=" + authoer
				+ "]";
	}
	
}
