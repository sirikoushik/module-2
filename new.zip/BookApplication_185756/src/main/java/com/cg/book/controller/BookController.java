package com.cg.book.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.book.bean.Book;
import com.cg.book.exception.NotFoundException;
import com.cg.book.service.IBookSer;
@RestController
public class BookController
{
	@Autowired
	IBookSer bookservice;
	 @RequestMapping(value="/byprice/{minPrice}/{maxPrice}",method=RequestMethod.GET) 
	    public List<Book> findByPriceRange(@PathVariable int minPrice,@PathVariable int maxPrice) throws NotFoundException{
	        return bookservice.findByPriceRange(minPrice,maxPrice);
	    }
	 @RequestMapping(value = "/bybookid/id")
		public Book getBookById(@RequestParam int id) throws NotFoundException {
			return bookservice.findByBookId(id);
		}
@PutMapping("/editbook")
	public Book updateCustomer(@RequestBody Book book) throws NotFoundException
	{
		return bookservice.editBook(book);
	}
}

