package com.cg.book.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.book.bean.Book;
import com.cg.book.dao.BookDao;
import com.cg.book.exception.NotFoundException;
@Service
public class BookServiceImpl implements IBookSer {
@Autowired
BookDao bookDao;

	@Override
	public Book findByBookId(int bid) throws NotFoundException {
		try{
		return bookDao.findById(bid).get();
		}catch(Exception e)
		{
			throw new NotFoundException("book with Id" +bid +" does not exsits");
		}
	}

	@Override
	public List<Book> findByPriceRange(double low, double high) {
		// TODO Auto-generated method stub
		return  bookDao.findByPriceRange(low, high);
	}



	@Override
	public Book editBook(Book book) throws NotFoundException {
		try{
			Optional<Book> optional=bookDao.findById(book.getBookId());
			if(optional.isPresent())
			{
				Book book1=optional.get();
				book1.setAuthoer(book1.getAuthoer());
				book1.setBookName(book1.getBookName());
				return bookDao.save(book);
			}
	
		else
		{
			throw new NotFoundException("book with Id" +book.getBookId() +" does not exsits");
		}
		}
		catch(Exception e)
		{
			throw new NotFoundException(e.getMessage());
		}
	}
	

}
