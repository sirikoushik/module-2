package com.cg.book.service;

import java.util.List;

import com.cg.book.bean.Book;
import com.cg.book.exception.NotFoundException;

public interface IBookSer
{
Book findByBookId(int bid) throws NotFoundException;
List<Book> findByPriceRange(double low, double high);
Book editBook(Book book) throws NotFoundException;

}
