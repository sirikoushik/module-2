package com.cg.book.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.book.bean.Book;


public interface BookDao extends JpaRepository<Book,Integer>
{
	 @Query("FROM Book WHERE bookPrice BETWEEN :p1 AND :p2")
	List<Book> findByPriceRange(@Param("p1") double low, @Param("p2") double high);
	

}
