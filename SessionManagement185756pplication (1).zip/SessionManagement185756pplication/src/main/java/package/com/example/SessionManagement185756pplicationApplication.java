package package.com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SessionManagement185756pplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SessionManagement185756pplicationApplication.class, args);
	}

}
